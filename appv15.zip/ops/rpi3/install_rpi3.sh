#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/autohunter"
REPO_URL="${REPO_URL:-}"   # opcional: export REPO_URL="https://..."

step() { echo; echo "==> $1"; }

step "1) Pacotes base"
sudo apt update
sudo apt install -y \
  git curl ca-certificates \
  python3 python3-venv python3-pip \
  build-essential pkg-config \
  libffi-dev libssl-dev \
  libjpeg-dev zlib1g-dev

step "2) Diretório"
sudo mkdir -p "$APP_DIR"
sudo chown -R "$USER":"$USER" "$APP_DIR"

step "3) Código"
if [ ! -d "$APP_DIR/.git" ] && [ -n "$REPO_URL" ]; then
  git clone "$REPO_URL" "$APP_DIR"
fi

if [ ! -f "$APP_DIR/requirements.txt" ] && [ ! -f "$APP_DIR/pyproject.toml" ]; then
  echo "⚠️ Não encontrei requirements.txt nem pyproject.toml em $APP_DIR."
  echo "Coloque o código do AutoHunter em $APP_DIR e rode novamente."
  exit 1
fi

cd "$APP_DIR"

step "4) Virtualenv + deps"
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip wheel

if [ -f requirements.txt ]; then
  pip install -r requirements.txt
else
  pip install -U poetry
  poetry install --no-interaction
fi

step "5) .env"
if [ ! -f "$APP_DIR/.env" ] && [ -f "$APP_DIR/ops/rpi3/autohunter.env.example" ]; then
  cp "$APP_DIR/ops/rpi3/autohunter.env.example" "$APP_DIR/.env"
  echo "Criei $APP_DIR/.env — edite antes de iniciar o serviço."
fi

step "6) systemd"
if [ -f "$APP_DIR/ops/rpi3/autohunter.service" ]; then
  sudo cp "$APP_DIR/ops/rpi3/autohunter.service" /etc/systemd/system/autohunter.service
  sudo systemctl daemon-reload
  sudo systemctl enable autohunter
  echo "OK: systemd instalado. Rode: sudo systemctl start autohunter"
  echo "Logs: sudo journalctl -u autohunter -f"
else
  echo "⚠️ Não encontrei ops/rpi3/autohunter.service no repo."
fi
