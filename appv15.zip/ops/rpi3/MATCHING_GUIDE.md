# Matching “leve” para evitar falso-positivo (ex.: Civic SI vs Civic genérico)

O problema clássico: se o filtro do scraper for só `"civic" in title`, você vai trazer **qualquer Civic**.

## O que está neste pacote

- `app/core/text_norm.py`: normalização (sem acentos, sem pontuação)
- `app/core/query_match.py`: regras include/exclude + score
- `tests/test_query_match.py`: casos para Civic SI e Civic Hatch

## Como integrar (mínimo)

1) Em qualquer source (MercadoLivre, Chaves na Mão, etc), antes de salvar/enviar alerta:

```python
from app.core.query_match import build_preset_rule, is_match

rule = build_preset_rule(wishlist.name)  # ex.: "civic si"
if not is_match(listing.title, rule):
    return None  # ignora resultado
```

2) Para refinar por wishlist (sem código): grave `include_all/include_any/exclude_any` no banco, e carregue numa `MatchRule`.

## Recomendações de preset pra entusiasta (BR)

- Sempre excluir: `type r`, `typer`, `turbo` quando não for o alvo.
- Para JDM/hot hatch, considerar tokens:
  - `vtec`, `b16`, `b18`, `k20`, `manual`
  - chassis: `eg`, `ek`, `dc2`, `ej`, `ep3`, `fn2` (depende do nicho)

> Curadoria = vantagem competitiva: você melhora o sinal sem aumentar crawling.
