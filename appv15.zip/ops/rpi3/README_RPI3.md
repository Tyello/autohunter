# AutoHunter — Execução 24/7 no Raspberry Pi 3 Model B (Lite + Systemd)

**Objetivo:** rodar o AutoHunter 24/7 com o menor consumo possível (CPU/RAM), usando **Raspberry Pi OS Lite** e **systemd**.

## 1) OS e pré-requisitos

- Recomendado: **Raspberry Pi OS Lite (32-bit)** (menos RAM). 
- Atualize o sistema:

```bash
sudo apt update && sudo apt -y full-upgrade
sudo reboot
```

## 2) Dependências nativas

```bash
sudo apt install -y \
  git curl ca-certificates \
  python3 python3-venv python3-pip \
  build-essential pkg-config \
  libffi-dev libssl-dev \
  libjpeg-dev zlib1g-dev
```

> Se seu projeto usa Postgres driver compilado (psycopg2), pode precisar: `sudo apt install -y libpq-dev`.

## 3) Deploy em /opt/autohunter

```bash
sudo mkdir -p /opt/autohunter
sudo chown -R $USER:$USER /opt/autohunter
cd /opt/autohunter
# copie o código do repo aqui (git clone ou scp)
```

Crie o venv e instale dependências:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip wheel

# Ajuste conforme seu projeto (requirements.txt / pyproject / etc)
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
elif [ -f pyproject.toml ]; then
  pip install -U poetry
  poetry install --no-interaction
fi
```

## 4) Variáveis de ambiente

Copie o template e preencha:

```bash
cp ops/rpi3/autohunter.env.example /opt/autohunter/.env
nano /opt/autohunter/.env
```

## 5) Criar o serviço systemd

Copie o serviço:

```bash
sudo cp ops/rpi3/autohunter.service /etc/systemd/system/autohunter.service
sudo systemctl daemon-reload
sudo systemctl enable autohunter
sudo systemctl start autohunter
```

Logs:

```bash
sudo journalctl -u autohunter -f
```

## 6) Tuning rápido (RPi 3)

- **1 worker** (sempre): `--workers 1`
- Intervalos de scraping: **mais longos** e com jitter (ex.: 10–20 min) para evitar picos.
- Use cache local (SQLite) para:
  - dedupe (source+external_id)
  - guardar último timestamp por wishlist
  - registrar “limite atingido” (não spammar o usuário)

## 7) Checklist de validação

- `/admin/health` retorna OK
- scheduler roda sem overlap (1 instância)
- cada source respeita rate-limit
- alertas não duplicam

