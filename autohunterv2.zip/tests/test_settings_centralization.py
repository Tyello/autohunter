from __future__ import annotations

import ast
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.core.settings import Settings


REPO_ROOT = Path(__file__).resolve().parents[1]
TARGET_DIRS = ("app", "config", "scripts")
ALLOWED_FILE = "app/core/settings.py"


def _iter_python_files() -> list[Path]:
    files: list[Path] = []
    for target in TARGET_DIRS:
        root = REPO_ROOT / target
        if not root.exists():
            continue
        files.extend(sorted(root.rglob("*.py")))
    return files


def _reads_env_directly(path: Path) -> bool:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name) and node.func.value.id == "os" and node.func.attr == "getenv":
                return True
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            if node.value.id == "os" and node.attr == "environ":
                return True
    return False


def test_only_settings_module_reads_environment_directly() -> None:
    offenders: list[str] = []
    for py_file in _iter_python_files():
        rel = py_file.relative_to(REPO_ROOT).as_posix()
        if rel == ALLOWED_FILE:
            continue
        if _reads_env_directly(py_file):
            offenders.append(rel)
    assert not offenders, f"Direct env reads found outside {ALLOWED_FILE}: {offenders}"


def test_settings_parsing_and_defaults() -> None:
    cfg = Settings(
        _env_file=None,
        database_url="sqlite:///tmp.db",
        playwright_service_port="9000",
        enable_playwright="false",
        log_stdout="true",
        use_new_scraper_sources="olx, webmotors",
    )

    assert cfg.database_url == "sqlite:///tmp.db"
    assert cfg.playwright_service_port == 9000
    assert cfg.enable_playwright is False
    assert cfg.log_stdout is True
    assert cfg.should_use_new_scraper_for("olx") is True
    assert cfg.should_use_new_scraper_for("mercadolivre") is False
    assert cfg.tracking_price_drop_alert_cooldown_hours == 24
    assert cfg.tracking_price_drop_alert_min_amount == 500
    assert cfg.tracking_price_drop_alert_min_pct == 1.0
    assert cfg.wishlist_summaries_cache_ttl_seconds == 10
    assert cfg.wishlist_summaries_cache_max_entries == 512
    assert cfg.db_pool_size == 5
    assert cfg.db_max_overflow == 5
    assert cfg.db_pool_recycle == 1800
    assert cfg.db_pool_timeout == 20
    assert cfg.db_connect_timeout == 10


def test_settings_requires_database_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DATABASE_URL", raising=False)
    with pytest.raises(ValidationError):
        Settings(_env_file=None)


def test_settings_auction_notification_gates_clamped() -> None:
    cfg = Settings(_env_file=None, database_url="sqlite:///tmp.db", auction_notifications_min_score=120, auction_notifications_max_lot_age_hours=900)
    assert cfg.auction_notifications_min_score_safe == 100
    assert cfg.auction_notifications_max_lot_age_hours_safe == 720
    cfg2 = Settings(_env_file=None, database_url="sqlite:///tmp.db", auction_notifications_min_score=-2, auction_notifications_max_lot_age_hours=0)
    assert cfg2.auction_notifications_min_score_safe == 0
    assert cfg2.auction_notifications_max_lot_age_hours_safe == 0
