from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ThreadPoolExecutor

from app.core.settings import settings

from app.db.session import SessionLocal

from app.services.system_logs_service import log
from app.sources import list_sources
from app.services.wishlist_sources_service import allowed_sources_for_wishlist
from app.services.source_availability_service import is_in_cooldown

from app.scheduler.jobs import scrape_ingest_match
from app.scheduler.heartbeat import heartbeat

from app.models.wishlist import Wishlist


def job_run_source_for_all_wishlists(source_name: str):
    with SessionLocal() as db:
        try:
            component = f"scheduler_{source_name}"
            log(db, "info", component, "job tick")

            wishlists = db.query(Wishlist).filter(Wishlist.is_active == True).all()
            if not wishlists:
                log(db, "info", component, "no active wishlists")
                return

            plugin = next((p for p in list_sources() if p.name == source_name), None)
            if plugin is None:
                log(db, "error", component, "unknown_source", {"source": source_name})
                return

            for w in wishlists:
                sources = allowed_sources_for_wishlist(db, w.id)

                if plugin.name not in sources:
                    log(db, "info", component, "skipped_filtered_out", {"wishlist_id": str(w.id), "source": plugin.name})
                    continue

                if plugin.enabled_setting and not getattr(settings, plugin.enabled_setting, False):
                    log(db, "info", component, "skipped_disabled", {"source": plugin.name})
                    continue

                if plugin.cooldown_minutes_setting:
                    cooldown = int(getattr(settings, plugin.cooldown_minutes_setting, 0) or 0)
                    if cooldown > 0 and is_in_cooldown(db, plugin.name, cooldown):
                        log(db, "info", component, "skipped_cooldown", {"source": plugin.name})
                        continue

                url = plugin.build_url(w.query)

                if plugin.scrape is None:
                    log(db, "warning", component, "not_implemented", {"wishlist_id": str(w.id), "query": w.query, "url": url})
                    continue

                log(db, "info", component, "job_started", {"wishlist_id": str(w.id), "query": w.query, "url": url})

                res = scrape_ingest_match(db, component, plugin.scrape, url, wishlist=w)

                log(db, "info", component, "job_finished", {
                    "wishlist_id": str(w.id),
                    "query": w.query,
                    "result": res,
                })


        except Exception as e:
            log(db, "error", f"scheduler_{source_name}", "job failed", {"error": str(e)})


def start_scheduler() -> BackgroundScheduler:
    sched = BackgroundScheduler(
        timezone="UTC",
        executors={"default": ThreadPoolExecutor(10)},
        job_defaults={
            "coalesce": True,
            "misfire_grace_time": 60,
            "max_instances": 1,
        },
    )

    # Pluggable sources: schedule every registered plugin that declares an interval.
    # This keeps scaling sources O(1): add plugin -> scheduler picks it up.
    for plugin in list_sources():
        if not plugin.supports_wishlist_monitoring:
            continue
        if not plugin.sched_minutes_setting:
            continue

        minutes = int(getattr(settings, plugin.sched_minutes_setting, 0) or 0)
        if minutes <= 0:
            # allow disabling a job by setting interval to 0
            continue

        job_id = f"{plugin.name}_job"
        sched.add_job(
            lambda n=plugin.name: job_run_source_for_all_wishlists(n),
            "interval",
            minutes=minutes,
            id=job_id,
        )

    def _job_heartbeat():
        db = SessionLocal()
        try:
            heartbeat(db)
            db.commit()
        finally:
            db.close()

    sched.add_job(_job_heartbeat, "interval", seconds=10, id="heartbeat")

    from app.scheduler.sender_job import job_send_notifications
    sched.add_job(
        job_send_notifications,
        "interval",
        seconds=settings.sched_sender_seconds,
        id="sender_job",
    )

    # Limpeza leve: mantém notifications enxutas (evita crescimento infinito)
    from app.scheduler.cleanup_job import job_cleanup_notifications
    sched.add_job(
        job_cleanup_notifications,
        "interval",
        hours=24,
        id="cleanup_notifications",
    )

    sched.start()
    return sched
