from typing import List
from sqlalchemy.orm import Session
from app.core.settings import settings

from app.services.system_logs_service import log
from app.services.source_availability_service import is_in_cooldown
from app.services.listings_service import ingest_listings

from app.models.car_listing import CarListing

from app.sources import list_sources
from app.scrapers.base import FetchBlocked


def manual_search(db: Session, query: str, limit: int = 5) -> List[CarListing]:
    # Pluggable sources: iterate registry
    for plugin in list_sources():
        if not plugin.supports_manual_search:
            continue
        if plugin.enabled_setting and not getattr(settings, plugin.enabled_setting, False):
            continue
        if plugin.scrape is None:
            continue

        if plugin.cooldown_minutes_setting:
            cooldown = int(getattr(settings, plugin.cooldown_minutes_setting, 0) or 0)
            if cooldown > 0 and is_in_cooldown(db, plugin.name, cooldown):
                continue

        url = plugin.build_url(query)

        try:
            items = plugin.scrape(url)
            ingest_listings(db, items)
        except FetchBlocked as e:
            log(db, "warning", f"scraper_{plugin.name}", "source_blocked", {"status_code": e.status_code, "url": e.url})
        except Exception as e:
            log(db, "error", f"scraper_{plugin.name}", "scrape_failed", {"error": str(e), "url": url})

    terms = [t for t in query.lower().split() if t]

    q = db.query(CarListing)

    # opcional: só coisas recentes (evita lixo antigo na busca manual)
    # q = q.filter(CarListing.created_at >= datetime.now(timezone.utc) - timedelta(hours=24))

    # match simples: todos os termos no título/location
    for t in terms:
        q = q.filter(
            (CarListing.title.ilike(f"%{t}%")) |
            (CarListing.location.ilike(f"%{t}%"))
        )

    return q.order_by(CarListing.created_at.desc()).limit(limit).all()