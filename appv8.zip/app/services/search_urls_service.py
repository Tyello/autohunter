from urllib.parse import quote_plus


def ml_url(query: str) -> str:
    q = quote_plus(query.strip())
    return f"https://lista.mercadolivre.com.br/{q}"


def olx_url(query: str) -> str:
    q = quote_plus(query.strip())
    return f"https://www.olx.com.br/brasil?q={q}"


def webmotors_url(query: str) -> str:
    # Webmotors é SPA e a busca real acontece via endpoints internos.
    # Para MVP, guardamos o URL de estoque (ainda útil para debug / futura implementação).
    q = quote_plus(query.strip())
    return f"https://www.webmotors.com.br/carros/estoque?tipoveiculo=carros&search={q}"


def gogarage_url(query: str) -> str:
    # GoGarage também carrega via JS. Mantemos um URL estável para a página de busca.
    q = quote_plus(query.strip())
    return f"https://gogarage.com.br/buscar?q={q}"


def chavesnamao_url(query: str) -> str:
    q = quote_plus(query.strip())
    return f"https://www.chavesnamao.com.br/carros-usados/brasil/?q={q}"
