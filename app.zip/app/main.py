from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List
from sqlalchemy.orm import Session

from app.db.models.car_listing import CarListing
from app.schemas.car_listing import CarListingOut


from app.db.deps import get_db

app = FastAPI(title="AutoHunter", version="0.1.0")

@app.get("/health")
def healthcheck():
    return {"status": "ok"}

@app.get("/db-check")
def db_check(db: Session = Depends(get_db)):
    db.execute(text("select 1"))
    return {"database": "connected"}

@app.get("/listings", response_model=List[CarListingOut])
def list_listings(
    source: str | None = None,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    query = db.query(CarListing)

    if source:
        query = query.filter(CarListing.source == source)

    listings = query.order_by(CarListing.created_at.desc()).limit(limit).all()
    return listings
